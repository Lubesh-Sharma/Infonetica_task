using WorkflowEngine.Models;
using System.Collections.Concurrent;

namespace WorkflowEngine.Storage;

/// <summary>
/// In-memory implementation of data storage for workflow definitions and instances.
/// Thread-safe implementation using ConcurrentDictionary for concurrent access scenarios.
/// Note: Data is volatile and will be lost when application restarts.
/// </summary>
public class InMemoryDataStore : IDataStore
{
    #region Private Fields

    /// <summary>
    /// Thread-safe storage for workflow definitions, indexed by definition ID
    /// </summary>
    private readonly ConcurrentDictionary<string, WorkflowDefinition> _definitions = new();
    
    /// <summary>
    /// Thread-safe storage for workflow instances, indexed by instance ID
    /// </summary>
    private readonly ConcurrentDictionary<string, WorkflowInstance> _instances = new();

    #endregion

    #region Workflow Definition Operations

    /// <summary>
    /// Persists or updates a workflow definition in memory
    /// </summary>
    /// <param name="definition">The workflow definition to save</param>
    /// <returns>Completed task</returns>
    public Task SaveWorkflowDefinitionAsync(WorkflowDefinition definition)
    {
        // AddOrUpdate ensures atomic operation for concurrent access
        _definitions.AddOrUpdate(definition.Id, definition, (key, oldValue) => definition);
        return Task.CompletedTask;
    }

    /// <summary>
    /// Retrieves a workflow definition by its unique identifier
    /// </summary>
    /// <param name="id">The unique identifier of the workflow definition</param>
    /// <returns>The workflow definition if found, otherwise null</returns>
    public Task<WorkflowDefinition?> GetWorkflowDefinitionAsync(string id)
    {
        _definitions.TryGetValue(id, out var definition);
        return Task.FromResult(definition);
    }

    /// <summary>
    /// Retrieves all workflow definitions from storage
    /// </summary>
    /// <returns>List of all workflow definitions</returns>
    public Task<List<WorkflowDefinition>> GetAllWorkflowDefinitionsAsync()
    {
        return Task.FromResult(_definitions.Values.ToList());
    }

    #endregion

    #region Workflow Instance Operations

    /// <summary>
    /// Persists or updates a workflow instance in memory
    /// </summary>
    /// <param name="instance">The workflow instance to save</param>
    /// <returns>Completed task</returns>
    public Task SaveWorkflowInstanceAsync(WorkflowInstance instance)
    {
        // AddOrUpdate ensures atomic operation for concurrent access
        _instances.AddOrUpdate(instance.Id, instance, (key, oldValue) => instance);
        return Task.CompletedTask;
    }

    /// <summary>
    /// Retrieves a workflow instance by its unique identifier
    /// </summary>
    /// <param name="id">The unique identifier of the workflow instance</param>
    /// <returns>The workflow instance if found, otherwise null</returns>
    public Task<WorkflowInstance?> GetWorkflowInstanceAsync(string id)
    {
        _instances.TryGetValue(id, out var instance);
        return Task.FromResult(instance);
    }

    /// <summary>
    /// Retrieves all workflow instances from storage
    /// </summary>
    /// <returns>List of all workflow instances</returns>
    public Task<List<WorkflowInstance>> GetAllWorkflowInstancesAsync()
    {
        return Task.FromResult(_instances.Values.ToList());
    }

    #endregion
}

using WorkflowEngine.Models;

namespace WorkflowEngine.Storage;

/// <summary>
/// Contract for data persistence layer supporting workflow definitions and instances.
/// Provides abstraction over storage implementation (in-memory, database, etc.)
/// </summary>
public interface IDataStore
{
    #region Workflow Definition Operations

    /// <summary>
    /// Persists a workflow definition to storage
    /// </summary>
    /// <param name="definition">The workflow definition to save</param>
    /// <returns>Task representing the asynchronous save operation</returns>
    Task SaveWorkflowDefinitionAsync(WorkflowDefinition definition);

    /// <summary>
    /// Retrieves a workflow definition by its unique identifier
    /// </summary>
    /// <param name="id">The unique identifier of the workflow definition</param>
    /// <returns>The workflow definition if found, otherwise null</returns>
    Task<WorkflowDefinition?> GetWorkflowDefinitionAsync(string id);

    /// <summary>
    /// Retrieves all workflow definitions from storage
    /// </summary>
    /// <returns>Collection of all workflow definitions</returns>
    Task<List<WorkflowDefinition>> GetAllWorkflowDefinitionsAsync();

    #endregion

    #region Workflow Instance Operations

    /// <summary>
    /// Persists a workflow instance to storage
    /// </summary>
    /// <param name="instance">The workflow instance to save</param>
    /// <returns>Task representing the asynchronous save operation</returns>
    Task SaveWorkflowInstanceAsync(WorkflowInstance instance);

    /// <summary>
    /// Retrieves a workflow instance by its unique identifier
    /// </summary>
    /// <param name="id">The unique identifier of the workflow instance</param>
    /// <returns>The workflow instance if found, otherwise null</returns>
    Task<WorkflowInstance?> GetWorkflowInstanceAsync(string id);

    /// <summary>
    /// Retrieves all workflow instances from storage
    /// </summary>
    /// <returns>Collection of all workflow instances</returns>
    Task<List<WorkflowInstance>> GetAllWorkflowInstancesAsync();

    #endregion
}

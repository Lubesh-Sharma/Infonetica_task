using WorkflowEngine.Services;
using WorkflowEngine.Storage;
using WorkflowEngine.DTOs;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container
builder.Services.AddSingleton<IDataStore, InMemoryDataStore>();
builder.Services.AddScoped<IWorkflowService, WorkflowService>();

var app = builder.Build();

// Add health check endpoint
app.MapGet("/health", () => Results.Ok(new { status = "healthy", timestamp = DateTime.UtcNow }))
.WithName("HealthCheck");

// Workflow Definition endpoints
app.MapPost("/api/workflow-definitions", async (IWorkflowService service, CreateWorkflowDefinitionDto dto) =>
{
    try
    {
        var definition = await service.CreateWorkflowDefinitionAsync(dto);
        return Results.Created($"/api/workflow-definitions/{definition.Id}", definition);
    }
    catch (ArgumentException ex)
    {
        return Results.BadRequest(new { error = ex.Message });
    }
})
.WithName("CreateWorkflowDefinition");

app.MapGet("/api/workflow-definitions/{id}", async (IWorkflowService service, string id) =>
{
    var definition = await service.GetWorkflowDefinitionAsync(id);
    return definition != null ? Results.Ok(definition) : Results.NotFound();
})
.WithName("GetWorkflowDefinition");

app.MapGet("/api/workflow-definitions", async (IWorkflowService service) =>
{
    var definitions = await service.GetAllWorkflowDefinitionsAsync();
    return Results.Ok(definitions);
})
.WithName("GetAllWorkflowDefinitions");

// Workflow Instance endpoints
app.MapPost("/api/workflow-instances", async (IWorkflowService service, string definitionId) =>
{
    try
    {
        var instance = await service.StartWorkflowInstanceAsync(definitionId);
        return Results.Created($"/api/workflow-instances/{instance.Id}", instance);
    }
    catch (ArgumentException ex)
    {
        return Results.BadRequest(new { error = ex.Message });
    }
})
.WithName("StartWorkflowInstance");

app.MapGet("/api/workflow-instances/{id}", async (IWorkflowService service, string id) =>
{
    var instance = await service.GetWorkflowInstanceAsync(id);
    return instance != null ? Results.Ok(instance) : Results.NotFound();
})
.WithName("GetWorkflowInstance");

app.MapGet("/api/workflow-instances", async (IWorkflowService service) =>
{
    var instances = await service.GetAllWorkflowInstancesAsync();
    return Results.Ok(instances);
})
.WithName("GetAllWorkflowInstances");

app.MapPost("/api/workflow-instances/{id}/execute", async (IWorkflowService service, string id, ExecuteActionDto dto) =>
{
    try
    {
        var instance = await service.ExecuteActionAsync(id, dto);
        return Results.Ok(instance);
    }
    catch (ArgumentException ex)
    {
        return Results.BadRequest(new { error = ex.Message });
    }
    catch (InvalidOperationException ex)
    {
        return Results.BadRequest(new { error = ex.Message });
    }
})
.WithName("ExecuteAction");

app.Run();

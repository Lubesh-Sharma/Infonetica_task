namespace WorkflowEngine.DTOs;

public class ExecuteActionDto
{
    public string ActionId { get; set; } = string.Empty;
}

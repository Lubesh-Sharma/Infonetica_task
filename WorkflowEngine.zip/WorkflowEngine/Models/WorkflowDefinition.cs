namespace WorkflowEngine.Models;

public class WorkflowDefinition
{
    public string Id { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public List<State> States { get; set; } = new();
    public List<WorkflowAction> Actions { get; set; } = new();
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public string? Description { get; set; }

    public void Validate()
    {
        if (string.IsNullOrWhiteSpace(Id))
            throw new ArgumentException("Workflow ID cannot be empty");
        
        if (string.IsNullOrWhiteSpace(Name))
            throw new ArgumentException("Workflow Name cannot be empty");
        
        if (!States.Any())
            throw new ArgumentException("Workflow must have at least one state");

        // Validate all states
        foreach (var state in States)
        {
            state.Validate();
        }

        // Check for duplicate state IDs
        var duplicateStateIds = States.GroupBy(s => s.Id).Where(g => g.Count() > 1).Select(g => g.Key);
        if (duplicateStateIds.Any())
            throw new ArgumentException($"Duplicate state IDs found: {string.Join(", ", duplicateStateIds)}");

        // Must have exactly one initial state
        var initialStates = States.Where(s => s.IsInitial).ToList();
        if (initialStates.Count != 1)
            throw new ArgumentException("Workflow must have exactly one initial state");

        // Validate all actions
        foreach (var action in Actions)
        {
            action.Validate();
        }

        // Check for duplicate action IDs
        var duplicateActionIds = Actions.GroupBy(a => a.Id).Where(g => g.Count() > 1).Select(g => g.Key);
        if (duplicateActionIds.Any())
            throw new ArgumentException($"Duplicate action IDs found: {string.Join(", ", duplicateActionIds)}");

        // Validate action state references
        var stateIds = States.Select(s => s.Id).ToHashSet();
        foreach (var action in Actions)
        {
            foreach (var fromState in action.FromStates)
            {
                if (!stateIds.Contains(fromState))
                    throw new ArgumentException($"Action '{action.Id}' references unknown source state '{fromState}'");
            }
            
            if (!stateIds.Contains(action.ToState))
                throw new ArgumentException($"Action '{action.Id}' references unknown target state '{action.ToState}'");
        }
    }

    public State GetInitialState()
    {
        return States.First(s => s.IsInitial);
    }
}

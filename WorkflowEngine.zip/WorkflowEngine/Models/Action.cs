namespace WorkflowEngine.Models;

public class WorkflowAction
{
    public string Id { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public bool Enabled { get; set; } = true;
    public List<string> FromStates { get; set; } = new();
    public string ToState { get; set; } = string.Empty;
    public string? Description { get; set; }

    public void Validate()
    {
        if (string.IsNullOrWhiteSpace(Id))
            throw new ArgumentException("Action ID cannot be empty");
        
        if (string.IsNullOrWhiteSpace(Name))
            throw new ArgumentException("Action Name cannot be empty");
        
        if (!FromStates.Any())
            throw new ArgumentException("Action must have at least one source state");
        
        if (string.IsNullOrWhiteSpace(ToState))
            throw new ArgumentException("Action must have a target state");
    }
}

using WorkflowEngine.Models;
using WorkflowEngine.DTOs;
using WorkflowEngine.Storage;

namespace WorkflowEngine.Services;

/// <summary>
/// Core business logic service for managing workflow definitions and instances.
/// Handles workflow creation, validation, execution, and state transitions.
/// </summary>
public class WorkflowService : IWorkflowService
{
    #region Private Fields

    private readonly IDataStore _dataStore;

    #endregion

    #region Constructor

    /// <summary>
    /// Initializes a new instance of the WorkflowService
    /// </summary>
    /// <param name="dataStore">Data persistence layer implementation</param>
    public WorkflowService(IDataStore dataStore)
    {
        _dataStore = dataStore ?? throw new ArgumentNullException(nameof(dataStore));
    }

    #endregion

    #region Workflow Definition Operations

    /// <summary>
    /// Creates and validates a new workflow definition from DTO
    /// </summary>
    /// <param name="dto">Data transfer object containing workflow definition data</param>
    /// <returns>The created and validated workflow definition</returns>
    /// <exception cref="ArgumentException">Thrown when validation fails</exception>
    public async Task<WorkflowDefinition> CreateWorkflowDefinitionAsync(CreateWorkflowDefinitionDto dto)
    {
        // Map DTO to domain model
        var definition = new WorkflowDefinition
        {
            Id = dto.Id,
            Name = dto.Name,
            Description = dto.Description,
            States = dto.States.Select(MapStateDto).ToList(),
            Actions = dto.Actions.Select(MapActionDto).ToList()
        };

        // Validate business rules and constraints
        definition.Validate();

        // Persist to storage
        await _dataStore.SaveWorkflowDefinitionAsync(definition);
        
        return definition;
    }

    /// <summary>
    /// Retrieves a workflow definition by its unique identifier
    /// </summary>
    /// <param name="id">The unique identifier of the workflow definition</param>
    /// <returns>The workflow definition if found, otherwise null</returns>
    public async Task<WorkflowDefinition?> GetWorkflowDefinitionAsync(string id)
    {
        return await _dataStore.GetWorkflowDefinitionAsync(id);
    }

    /// <summary>
    /// Retrieves all workflow definitions
    /// </summary>
    /// <returns>Collection of all workflow definitions</returns>
    public async Task<List<WorkflowDefinition>> GetAllWorkflowDefinitionsAsync()
    {
        return await _dataStore.GetAllWorkflowDefinitionsAsync();
    }

    #endregion

    #region Workflow Instance Operations

    /// <summary>
    /// Creates and starts a new workflow instance from a definition
    /// </summary>
    /// <param name="definitionId">The unique identifier of the workflow definition</param>
    /// <returns>The newly created workflow instance</returns>
    /// <exception cref="ArgumentException">Thrown when definition is not found</exception>
    public async Task<WorkflowInstance> StartWorkflowInstanceAsync(string definitionId)
    {
        // Validate definition exists
        var definition = await _dataStore.GetWorkflowDefinitionAsync(definitionId);
        if (definition == null)
            throw new ArgumentException($"Workflow definition '{definitionId}' not found", nameof(definitionId));

        // Initialize instance at initial state
        var initialState = definition.GetInitialState();
        var instance = new WorkflowInstance
        {
            DefinitionId = definitionId,
            CurrentStateId = initialState.Id
        };

        // Persist new instance
        await _dataStore.SaveWorkflowInstanceAsync(instance);
        
        return instance;
    }

    /// <summary>
    /// Retrieves a workflow instance by its unique identifier
    /// </summary>
    /// <param name="instanceId">The unique identifier of the workflow instance</param>
    /// <returns>The workflow instance if found, otherwise null</returns>
    public async Task<WorkflowInstance?> GetWorkflowInstanceAsync(string instanceId)
    {
        return await _dataStore.GetWorkflowInstanceAsync(instanceId);
    }

    /// <summary>
    /// Retrieves all workflow instances
    /// </summary>
    /// <returns>Collection of all workflow instances</returns>
    public async Task<List<WorkflowInstance>> GetAllWorkflowInstancesAsync()
    {
        return await _dataStore.GetAllWorkflowInstancesAsync();
    }

    /// <summary>
    /// Executes an action on a workflow instance, transitioning states
    /// </summary>
    /// <param name="instanceId">The unique identifier of the workflow instance</param>
    /// <param name="dto">Action execution request containing action identifier</param>
    /// <returns>The updated workflow instance after action execution</returns>
    /// <exception cref="ArgumentException">Thrown when instance or action is not found</exception>
    /// <exception cref="InvalidOperationException">Thrown when action cannot be executed</exception>
    public async Task<WorkflowInstance> ExecuteActionAsync(string instanceId, ExecuteActionDto dto)
    {
        // Retrieve and validate instance exists
        var instance = await GetAndValidateInstanceAsync(instanceId);
        
        // Retrieve and validate definition exists
        var definition = await GetAndValidateDefinitionAsync(instance.DefinitionId);
        
        // Validate current state and action
        var currentState = ValidateCurrentState(definition, instance);
        var action = ValidateAction(definition, dto.ActionId, instance.CurrentStateId);
        var targetState = ValidateTargetState(definition, action.ToState);

        // Execute state transition
        await ExecuteStateTransitionAsync(instance, action);
        
        return instance;
    }

    #endregion

    #region Private Helper Methods

    /// <summary>
    /// Maps StateDto to State domain model
    /// </summary>
    private static State MapStateDto(StateDto stateDto) => new()
    {
        Id = stateDto.Id,
        Name = stateDto.Name,
        IsInitial = stateDto.IsInitial,
        IsFinal = stateDto.IsFinal,
        Enabled = stateDto.Enabled,
        Description = stateDto.Description
    };

    /// <summary>
    /// Maps ActionDto to WorkflowAction domain model
    /// </summary>
    private static WorkflowAction MapActionDto(ActionDto actionDto) => new()
    {
        Id = actionDto.Id,
        Name = actionDto.Name,
        Enabled = actionDto.Enabled,
        FromStates = actionDto.FromStates.ToList(),
        ToState = actionDto.ToState,
        Description = actionDto.Description
    };

    /// <summary>
    /// Retrieves and validates that a workflow instance exists
    /// </summary>
    private async Task<WorkflowInstance> GetAndValidateInstanceAsync(string instanceId)
    {
        var instance = await _dataStore.GetWorkflowInstanceAsync(instanceId);
        if (instance == null)
            throw new ArgumentException($"Workflow instance '{instanceId}' not found", nameof(instanceId));
        
        return instance;
    }

    /// <summary>
    /// Retrieves and validates that a workflow definition exists
    /// </summary>
    private async Task<WorkflowDefinition> GetAndValidateDefinitionAsync(string definitionId)
    {
        var definition = await _dataStore.GetWorkflowDefinitionAsync(definitionId);
        if (definition == null)
            throw new InvalidOperationException($"Workflow definition '{definitionId}' not found");
        
        return definition;
    }

    /// <summary>
    /// Validates the current state of a workflow instance
    /// </summary>
    private static State ValidateCurrentState(WorkflowDefinition definition, WorkflowInstance instance)
    {
        var currentState = definition.States.FirstOrDefault(s => s.Id == instance.CurrentStateId);
        if (currentState == null)
            throw new InvalidOperationException($"Current state '{instance.CurrentStateId}' not found in definition");

        if (currentState.IsFinal)
            throw new InvalidOperationException("Cannot execute actions on a workflow instance in a final state");

        return currentState;
    }

    /// <summary>
    /// Validates that an action can be executed from the current state
    /// </summary>
    private static WorkflowAction ValidateAction(WorkflowDefinition definition, string actionId, string currentStateId)
    {
        var action = definition.Actions.FirstOrDefault(a => a.Id == actionId);
        if (action == null)
            throw new ArgumentException($"Action '{actionId}' not found in workflow definition");

        if (!action.Enabled)
            throw new InvalidOperationException($"Action '{actionId}' is disabled");

        if (!action.FromStates.Contains(currentStateId))
            throw new InvalidOperationException($"Action '{actionId}' cannot be executed from current state '{currentStateId}'");

        return action;
    }

    /// <summary>
    /// Validates that the target state exists in the definition
    /// </summary>
    private static State ValidateTargetState(WorkflowDefinition definition, string targetStateId)
    {
        var targetState = definition.States.FirstOrDefault(s => s.Id == targetStateId);
        if (targetState == null)
            throw new InvalidOperationException($"Target state '{targetStateId}' not found in definition");

        return targetState;
    }

    /// <summary>
    /// Executes the state transition and updates the instance
    /// </summary>
    private async Task ExecuteStateTransitionAsync(WorkflowInstance instance, WorkflowAction action)
    {
        // Create history entry for audit trail
        var historyEntry = new ActionHistory
        {
            ActionId = action.Id,
            ActionName = action.Name,
            FromStateId = instance.CurrentStateId,
            ToStateId = action.ToState
        };

        // Update instance state
        instance.CurrentStateId = action.ToState;
        instance.History.Add(historyEntry);
        instance.UpdatedAt = DateTime.UtcNow;

        // Persist changes
        await _dataStore.SaveWorkflowInstanceAsync(instance);
    }

    #endregion
}

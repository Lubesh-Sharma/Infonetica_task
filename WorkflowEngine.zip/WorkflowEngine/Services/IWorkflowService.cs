using WorkflowEngine.Models;
using WorkflowEngine.DTOs;

namespace WorkflowEngine.Services;

public interface IWorkflowService
{
    Task<WorkflowDefinition> CreateWorkflowDefinitionAsync(CreateWorkflowDefinitionDto dto);
    Task<WorkflowDefinition?> GetWorkflowDefinitionAsync(string id);
    Task<List<WorkflowDefinition>> GetAllWorkflowDefinitionsAsync();
    
    Task<WorkflowInstance> StartWorkflowInstanceAsync(string definitionId);
    Task<WorkflowInstance?> GetWorkflowInstanceAsync(string instanceId);
    Task<List<WorkflowInstance>> GetAllWorkflowInstancesAsync();
    Task<WorkflowInstance> ExecuteActionAsync(string instanceId, ExecuteActionDto dto);
}
